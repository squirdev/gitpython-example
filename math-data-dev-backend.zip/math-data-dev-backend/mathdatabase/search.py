import os
from git import Repo


def find(mdb,  datatype, text):
    """Return the keys of instances matching text.
    """
    # Return SHA keys
    return []

def search(mdb,  text):
    """Return the instances matching text.
    """

def filter(mdb,  criteria):
    """Retrieve instances from the mathdatabase matching criteria.
    """
    instances = []
    return instances
