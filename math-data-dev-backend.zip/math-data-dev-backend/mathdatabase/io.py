import os
from git import Repo

def add_instance(mdb, datatype, instance):
    """Add an instance in the mathdatabase.
    """

def remove_instance(mdb,  instance):
    """Remove an instance from the mathdatabase.
    """

def retrieve_instance(mdb,  key):
    """Retrieve an instance from the mathdatabase.
    """
    instance = {}
    return instance
